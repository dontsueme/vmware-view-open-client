function externalLinks() {  

 if (!document.getElementsByTagName) return;   
 var anchors = document.getElementsByTagName("a");   
 for (var i=0; i<anchors.length; i++) {   
   var anchor = anchors[i];   
   if (anchor.getAttribute("href") &&   
       anchor.getAttribute("rel") == "external")   
     anchor.target = "_blank";   
 }   

 //hideScriptDisabled();
}  
 
window.onload = externalLinks;

function SendFeedback() {
    var loc = location.href;
    
    loc = "mailto:docfeedback@vmware.com?Subject=" + loc;
    location.href = loc;
}

function hideScriptDisabled() {
  document.getElementById("scriptDisabled").style.display = "none";
  document.getElementById("scriptEnabled").style.display = "";
}